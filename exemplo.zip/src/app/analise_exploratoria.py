import streamlit as st


def page():
    st.title('Análise exploratória')
    