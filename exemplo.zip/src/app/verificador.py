import streamlit as st
import joblib


model = joblib.load('models/best_model.joblib')

def foo(y_hat):
    saida = 'Pinguin com '
    if y_hat[1] > .4 and y_hat[1] < .6:
        saida = 'O modelo não tem certeza do sexo do pinguin. Por favor verifique no site tal...'
    elif y_hat[1] < .5:
        saida = saida + f'{y_hat[0]*100:.2f}% de probabilidade de ser fêmea.'
    else:
        saida = saida + f'{y_hat[1]*100:.2f}% de probabilidade de ser macho.'
    return saida


def page():
    st.title("Detector de fakenews")
    st.text_area("Adicione parte da notícia ou um link para a mesma.")
    if st.button("Verificar"):
        with st.spinner(text='Consultando modelo...'):
            # receber notícia e jogar no modelo
            X_ = pd.DataFrame(
                {
                    'species': ['Adelie'],
                    'island': ['Torgersen'],
                    'bill_length_mm': [39.1],
                    'bill_depth_mm': [18.7],
                    'flipper_length_mm': [181.0],
                    'body_mass_g': [3750.0]
                }
            )
            y_hat = model.predict_proba(X_)[0]
            texto_saida = foo(y_hat)
            st.text(texto_saida)