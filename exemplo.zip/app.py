
from time import sleep
from st_on_hover_tabs import on_hover_tabs
import streamlit as st
import pandas as pd
from src.app import verificador, analise_exploratoria, analise_comparativa, sobre


st.set_page_config(layout="wide")
st.markdown('<style>' + open('./style.css').read() + '</style>', unsafe_allow_html=True)
with st.sidebar:
    tabs = on_hover_tabs(
        tabName=['Verificador', 'Análise exploratória', 'Análise comparativa', 'Sobre'],
        iconName=['check_circle', 'search', 'analytics', 'info'],
        default_choice=0,
        styles = {
            'navtab': {'text-transform': 'Captalize'}
        }
    )
if tabs == 'Verificador':
    verificador.page()     
if tabs == 'Análise exploratória':
    analise_exploratoria.page()
if tabs == 'Análise comparativa':
    analise_comparativa.page()
if tabs == 'Sobre':
    sobre.page()